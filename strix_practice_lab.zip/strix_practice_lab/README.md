# Strix AI Practice Lab

A deliberately vulnerable local Flask web application for learning how an authorized AI security-testing tool such as Strix identifies web vulnerabilities.

## Important

This project is intentionally insecure. Run it only on your own computer and do not expose it to the public internet.

The app contains examples of:
- Weak authentication / hard-coded demo credentials
- IDOR (Insecure Direct Object Reference)
- Reflected XSS
- Missing authorization on an admin-style endpoint
- Sensitive information exposed by an API response

These vulnerabilities are intentionally simple so you can observe how a security-testing agent discovers and explains them.

## Requirements

- Windows 10/11
- Python 3.10+ recommended

## 1. Open the project

Extract the ZIP and open Command Prompt or PowerShell in the `strix_practice_lab` folder.

## 2. Create a virtual environment

PowerShell:

    py -m venv .venv
    .\.venv\Scripts\Activate.ps1

If PowerShell blocks activation, use Command Prompt:

    py -m venv .venv
    .venv\Scripts\activate.bat

## 3. Install Flask

    python -m pip install --upgrade pip
    pip install -r requirements.txt

## 4. Run the application

    python app.py

You should see the Flask development server start on:

    http://127.0.0.1:5000

Open that address in your browser.

## Demo accounts

Student:
    student / student123

Admin:
    admin / admin123

The credentials are intentionally weak because this is a security-testing lab.

## Main routes

    /                 Home page
    /login            Login
    /dashboard        Dashboard
    /profile/<id>     Student profile
    /search           Search page
    /api/students     Student API
    /admin            Admin-style page

## Testing with Strix

Point Strix only at the local application you own/control, using:

    http://127.0.0.1:5000

Ask it to perform an authorized security assessment of the application.

Good things to observe:
1. How it discovers routes.
2. How it identifies authentication weaknesses.
3. Whether it notices that changing a profile ID exposes another student's data.
4. Whether it recognizes the search parameter as reflected HTML/JavaScript input.
5. Whether it notices that `/admin` does not properly enforce authorization.
6. How it provides evidence and remediation advice.

## Expected lab findings

The application intentionally includes these learning targets:

### 1. IDOR
Try:

    http://127.0.0.1:5000/profile/1
    http://127.0.0.1:5000/profile/2

The application does not verify that the logged-in user owns the requested profile.

### 2. Reflected XSS
The search page intentionally reflects the `q` parameter into HTML without escaping it.

For a local lab demonstration, a harmless proof of concept is:

    <script>alert('XSS demo')</script>

URL-encode it when putting it in the URL.

### 3. Missing authorization
The `/admin` route checks whether the user is logged in but intentionally does not properly verify an admin role.

### 4. Sensitive API data
The student API returns more fields than a normal public endpoint should expose.

## Stopping the server

Press:

    Ctrl+C

## Resetting the lab

The app uses an in-memory dataset, so restarting the server resets the demo data.

## Safety

Do not deploy this project to a public server. It is intentionally vulnerable.
