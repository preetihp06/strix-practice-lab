from flask import Flask, request, redirect, url_for, session, render_template, jsonify

app = Flask(__name__)

# INTENTIONALLY INSECURE:
# A real application should load this from a secure environment variable.
app.secret_key = "strix-practice-secret-key"

# Demo data only. Do not use real personal information.
USERS = {
    "student": {
        "password": "student123",
        "role": "student",
        "student_id": 1
    },
    "admin": {
        "password": "admin123",
        "role": "admin",
        "student_id": 2
    }
}

STUDENTS = {
    1: {
        "id": 1,
        "name": "Aarav Sharma",
        "email": "aarav@example.test",
        "course": "Computer Science",
        "attendance": 87,
        "internal_note": "Demo record - not real data"
    },
    2: {
        "id": 2,
        "name": "Meera Patel",
        "email": "meera@example.test",
        "course": "Information Technology",
        "attendance": 92,
        "internal_note": "Demo admin record - not real data"
    },
    3: {
        "id": 3,
        "name": "Rohan Desai",
        "email": "rohan@example.test",
        "course": "Computer Engineering",
        "attendance": 78,
        "internal_note": "Demo record - not real data"
    }
}


@app.route("/")
def index():
    return render_template("index.html", user=session.get("username"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        user = USERS.get(username)

        # Intentionally simple/weak authentication for the lab.
        if user and user["password"] == password:
            session["username"] = username
            session["role"] = user["role"]
            session["student_id"] = user["student_id"]
            return redirect(url_for("dashboard"))

        error = "Invalid username or password."

    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    if "username" not in session:
        return redirect(url_for("login"))

    student = STUDENTS.get(session["student_id"])
    return render_template(
        "dashboard.html",
        username=session["username"],
        role=session["role"],
        student=student
    )


@app.route("/profile/<int:student_id>")
def profile(student_id):
    if "username" not in session:
        return redirect(url_for("login"))

    # INTENTIONALLY VULNERABLE TO IDOR:
    # No ownership/authorization check is performed.
    student = STUDENTS.get(student_id)

    if not student:
        return "Student not found", 404

    return render_template("profile.html", student=student)


@app.route("/search")
def search():
    query = request.args.get("q", "")

    # INTENTIONALLY VULNERABLE TO REFLECTED XSS:
    # The template deliberately marks the query as safe.
    return render_template("search.html", query=query)


@app.route("/api/students")
def api_students():
    if "username" not in session:
        return jsonify({"error": "login required"}), 401

    # INTENTIONALLY OVER-EXPOSED:
    # Internal notes and other student records are returned.
    return jsonify(list(STUDENTS.values()))


@app.route("/admin")
def admin():
    if "username" not in session:
        return redirect(url_for("login"))

    # INTENTIONALLY VULNERABLE:
    # This page should verify session["role"] == "admin",
    # but it only checks whether the user is logged in.
    return render_template("admin.html", students=list(STUDENTS.values()))


if __name__ == "__main__":
    # Local-only binding for the practice lab.
    app.run(host="127.0.0.1", port=5000, debug=False)
